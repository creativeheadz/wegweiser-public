import os
import sys
import pkg_resources
import shutil
import modulefinder
import site
from pathlib import Path

class LokiDependencyAnalyzer:
    def __init__(self, venv_path):
        self.venv_path = Path(venv_path)
        self.site_packages = self.venv_path / 'Lib' / 'site-packages'
        self.required_files = set()
        self.required_packages = {
            'colorama': ['colorama'],
            'yara-python': ['yara'],
            'psutil': ['psutil'],
            'wmi': ['wmi'],
            'win32': ['win32com', 'win32api', 'win32con', 'win32file', 'win32security'],
            'rfc5424-logging-handler': ['rfc5424logging'],
            'netaddr': ['netaddr']
        }

    def analyze_dependencies(self):
        """Analyze Loki's Python dependencies"""
        found_packages = {}
        missing_packages = []
        
        print("Analyzing installed packages...")
        
        # Check installed packages
        installed_packages = {pkg.key: pkg for pkg in pkg_resources.working_set}
        
        for package, modules in self.required_packages.items():
            if package in installed_packages:
                found_packages[package] = installed_packages[package].version
                # Find all module files
                for module in modules:
                    try:
                        module_path = self.find_module_path(module)
                        if module_path:
                            if os.path.isdir(module_path):
                                # If it's a directory, add all .py and .pyd files
                                for root, _, files in os.walk(module_path):
                                    for file in files:
                                        if file.endswith(('.py', '.pyd', '.dll')):
                                            self.required_files.add(os.path.join(root, file))
                            else:
                                self.required_files.add(module_path)
                    except ImportError:
                        missing_packages.append(module)
            else:
                missing_packages.append(package)

        return {
            'found': found_packages,
            'missing': missing_packages,
            'files': sorted(list(self.required_files))
        }

    def find_module_path(self, module_name):
        """Find the path of a module in the virtual environment"""
        try:
            module = __import__(module_name)
            if hasattr(module, '__file__'):
                return os.path.dirname(module.__file__) if os.path.isfile(module.__file__) else module.__file__
        except ImportError:
            pass
        
        # Check in site-packages directly
        potential_paths = [
            self.site_packages / module_name,
            self.site_packages / f"{module_name}.py",
            self.site_packages / f"{module_name}.pyd"
        ]
        
        for path in potential_paths:
            if path.exists():
                return str(path)
        
        return None

    def create_minimal_package(self, output_dir):
        """Create a minimal package with just the required files"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Copy required files maintaining directory structure
        for file in self.required_files:
            rel_path = os.path.relpath(file, self.site_packages)
            dest_path = output_dir / rel_path
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file, dest_path)
            
        # Create requirements.txt
        with open(output_dir / 'requirements.txt', 'w') as f:
            for package, version in self.analyze_dependencies()['found'].items():
                f.write(f'{package}=={version}\n')

    def print_analysis(self):
        """Print detailed analysis results"""
        analysis = self.analyze_dependencies()
        
        print("\nDependency Analysis Report")
        print("=" * 50)
        
        print("\nFound Packages:")
        for package, version in analysis['found'].items():
            print(f"  - {package} (v{version})")
            
        if analysis['missing']:
            print("\nMissing Packages:")
            for package in analysis['missing']:
                print(f"  - {package}")
                
        print("\nRequired Files:")
        for file in analysis['files']:
            print(f"  - {file}")
            
        return analysis

def main():
    # Get virtual environment path
    if len(sys.argv) < 2:
        print("Usage: python dependency_analyzer.py <path_to_venv>")
        sys.exit(1)
        
    venv_path = sys.argv[1]
    analyzer = LokiDependencyAnalyzer(venv_path)
    
    # Print analysis
    analysis = analyzer.print_analysis()
    
    # Create minimal package
    output_dir = "loki_minimal_package"
    analyzer.create_minimal_package(output_dir)
    print(f"\nMinimal package created in: {output_dir}")

if __name__ == "__main__":
    main()