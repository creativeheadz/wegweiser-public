#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
# -*- coding: utf-8 -*-
#
# Levenshtein related functions, file monitoring and process checks

import os
import logging
import psutil  # For process checking
import hashlib  # To hash files for further checks

# Configure logging
logging.basicConfig(filename='file_check.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

CHECK_FILES = [
    'svchost.exe', 'explorer.exe', 'iexplore.exe', 'lsass.exe', 'chrome.exe', 'csrss.exe', 'firefox.exe',
    'winlogon.exe', 'notepad.exe', 'taskmgr.exe', 'powershell.exe', 'cmd.exe', 'msedge.exe', 'wmiprvse.exe'
]

class LevCheck:

    def __init__(self):
        pass

    def check(self, fileName):
        """
        Check if file name is very similar to a file in the check list
        :param fileName: File name to check
        :return: Similar file name from CHECK_FILES if levenshtein distance is 1, else None
        """
        for checkFile in CHECK_FILES:
            if levenshtein(checkFile, fileName) == 1:
                logging.warning(f'Suspicious file detected: {fileName} is similar to {checkFile}')
                return checkFile
        return None

    def check_hash(self, filePath):
        """
        Compute and log the hash of a file for further validation
        :param filePath: Path to the file
        :return: MD5 hash of the file
        """
        try:
            hasher = hashlib.md5()
            with open(filePath, 'rb') as afile:
                buf = afile.read()
                hasher.update(buf)
            file_hash = hasher.hexdigest()
            logging.info(f"File {filePath} has MD5 hash: {file_hash}")
            return file_hash
        except FileNotFoundError:
            logging.error(f"File not found: {filePath}")
            return None

    def check_processes(self):
        """
        Check for running processes that match or are similar to the CHECK_FILES
        :return: List of suspicious processes
        """
        suspicious_processes = []
        for proc in psutil.process_iter(['pid', 'name']):
            process_name = proc.info['name']
            for checkFile in CHECK_FILES:
                if levenshtein(checkFile, process_name) == 1:
                    suspicious_processes.append(proc.info)
                    logging.warning(f'Suspicious process detected: {process_name} (PID: {proc.info["pid"]}) is similar to {checkFile}')
        return suspicious_processes

def levenshtein(s, t):
    """
    Compute the Levenshtein distance between two strings
    :param s: First string
    :param t: Second string
    :return: Distance (integer)
    """
    if s == t:
        return 0
    elif len(s) == 0:
        return len(t)
    elif len(t) == 0:
        return len(s)

    v0 = [None] * (len(t) + 1)
    v1 = [None] * (len(t) + 1)

    for i in range(len(v0)):
        v0[i] = i

    for i in range(len(s)):
        v1[0] = i + 1
        for j in range(len(t)):
            cost = 0 if s[i] == t[j] else 1
            v1[j + 1] = min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost)

        for j in range(len(v0)):
            v0[j] = v1[j]

    return v1[len(t)]


# Example usage
if __name__ == "__main__":
    checker = LevCheck()

    # Check a file name
    file_to_check = 'svhost.exe'
    similar_file = checker.check(file_to_check)
    if similar_file:
        logging.info(f'File {file_to_check} is similar to {similar_file}')

    # Check running processes for suspicious activity
    suspicious_procs = checker.check_processes()
    if suspicious_procs:
        for proc in suspicious_procs:
            logging.warning(f'Suspicious process detected: {proc}')

    # Check file hash for validation
    file_path = '/path/to/svhost.exe'
    file_hash = checker.check_hash(file_path)
