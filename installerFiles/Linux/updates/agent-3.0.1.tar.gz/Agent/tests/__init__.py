"""Tests for Wegweiser Agent"""

